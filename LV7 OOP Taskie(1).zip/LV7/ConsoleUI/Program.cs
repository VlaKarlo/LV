﻿using System;
using System.Collections.Generic;
using Taskie;
using Taskie.Data;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Test();
        }

        public static void Test()
        {
            ITaskDao taskDao = new TaskRepository();
            List<ToDoTask> tasks = new List<ToDoTask>();

            Console.Write("Title: ");
            string title = Console.ReadLine();
            Console.Write("Importance: ");
            int importance = int.Parse(Console.ReadLine());
            Console.WriteLine("Time: ");
            DateTime time = DateTime.Now;
            
            ToDoTask t = new TimedTask(title, importance, time);
            taskDao.SaveTask(t);
            t = new TimedTask("naziv", 2, DateTime.Now);
            taskDao.SaveTask(t);

            tasks = (List<ToDoTask>)taskDao.GetTasks();

            Console.WriteLine("List:");
            Console.WriteLine(string.Join(Environment.NewLine, tasks));

            Console.WriteLine("Removing...");
            taskDao.Delete(t);
            tasks = (List<ToDoTask>)taskDao.GetTasks();

            Console.WriteLine("List:");
            Console.WriteLine(string.Join(", ", tasks));

            Console.ReadKey();
        }
    }
}
