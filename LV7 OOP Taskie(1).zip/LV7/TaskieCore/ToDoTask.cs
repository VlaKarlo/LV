﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taskie
{
    public class ToDoTask
    {
        private string title;
        private int importance;
        private readonly int minImportance = 1;
        private readonly int maxImportance = 3;

        public string Title
        {
            get { return title; }
            private set { title = value; }
        }
        public int Importance
        {
            get { return importance; }
            private set { importance = value; }
        }

        public ToDoTask()
        {
            title = "Taks";
            importance = 1;
        }
        public ToDoTask(string title, int importance)
        {
            this.title = title;
            if (importance >= minImportance || importance <= maxImportance)
                this.importance = importance;
            else this.importance = 1;
        }

        public override string ToString()
        {
            return $"Task title: {Title}, importance level: {Importance}" +
                $"";
        }
    }
}
