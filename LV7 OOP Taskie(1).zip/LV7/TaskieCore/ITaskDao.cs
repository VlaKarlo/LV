﻿using System.Collections.Generic;

namespace Taskie.Data
{
    public interface ITaskDao 
    {
        void SaveTask(ToDoTask task);
        IEnumerable<ToDoTask> GetTasks();
        void DeleteByTitle(string title);
        void Delete(ToDoTask taskToRemove);
    }
}
