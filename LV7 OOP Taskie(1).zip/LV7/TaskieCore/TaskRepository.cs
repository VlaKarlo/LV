﻿using System.Collections.Generic;

namespace Taskie.Data
{
    public class TaskRepository : ITaskDao
    {
        List<ToDoTask> tasks;
        public TaskRepository()
        {
            tasks = new List<ToDoTask>();
        }
        public void Delete(ToDoTask taskToRemove)
        {
            tasks.Remove(taskToRemove);
        }

        public void DeleteByTitle(string title)
        {

            tasks.RemoveAll(it => it.Title == title);
            
        }

        public IEnumerable<ToDoTask> GetTasks()
        {
            return tasks;
        }

        public void SaveTask(ToDoTask task)
        {
            tasks.Add(task);
        }
    }
}
