﻿using System;

namespace Taskie
{
    public class TimedTask : ToDoTask
    {
        private DateTime deadline;

        public TimedTask() : base()
        {
            deadline = DateTime.Now;
        }
        public TimedTask(string title, int importance, DateTime deadline) : base(title, importance)
        {
            this.deadline = deadline;
        }

        public TimeSpan CalcTimeLeft()
        {
            if (deadline >= DateTime.Now) return TimeSpan.Zero;
            return deadline - DateTime.Now;
        }
        public override string ToString()
        {
            return base.ToString() + $", deadline: {deadline}";
        }
    }
}

